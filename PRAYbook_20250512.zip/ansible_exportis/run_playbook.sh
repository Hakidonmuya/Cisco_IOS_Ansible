#!/bin/bash

# Script to run Ansible playbook for Cisco 4200 Series routers (FastEthernet, PC1 on Sub-rede 1, PC2 on Sub-rede 3, Link on Sub-rede 2)
cd ~/ansible || { echo "Error: Could not navigate to ~/ansible"; exit 1; }

# Activate virtual environment
if [ -f "venv/bin/activate" ]; then
    source venv/bin/activate
else
    echo "Error: Virtual environment not found. Please create it with: python3 -m venv venv"
    exit 1
fi

# Set default target
TARGET="all"
CHECK_MODE=""

# Parse arguments
for arg in "$@"; do
    case $arg in
        --router2)
            TARGET="router2"
            ;;
        --router3)
            TARGET="router3"
            ;;
        --check)
            CHECK_MODE="--check"
            ;;
        *)
            echo "Error: Invalid argument '$arg'. Use --router2, --router3, or --check."
            exit 1
            ;;
    esac
done

# Run Ansible playbook
if [ -f "configure_network.yml" ]; then
    echo "Running playbook for Cisco 4200 Series (FastEthernet, PC1 on Sub-rede 1, PC2 on Sub-rede 3, Link on Sub-rede 2) target: $TARGET"
    ansible-playbook -i inventory.yml configure_network.yml $CHECK_MODE --limit "$TARGET"
    EXIT_CODE=$?
else
    echo "Error: configure_network.yml not found in ~/ansible"
    exit 1
fi

# Check playbook execution
if [ $EXIT_CODE -ne 0 ]; then
    echo "Error: Playbook execution failed with exit code $EXIT_CODE"
    exit $EXIT_CODE
else
    echo "Playbook executed successfully for $TARGET!"
fi

# Deactivate virtual environment
deactivate
